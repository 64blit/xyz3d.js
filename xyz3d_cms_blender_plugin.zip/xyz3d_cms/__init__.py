# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "xyz3d cms",
    "author" : "64blit", 
    "description" : "xyz3d cms helper addon that sets the selected objects custom properties and allows for easy exporting",
    "blender" : (3, 0, 0),
    "version" : (0, 0, 2),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Import-Export" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
operations = {'sna_selected': None, }


def sna_setpropertydataandtarget_805E1(layout_function, label, name, value, icon):
    box_1B8E1 = layout_function.box()
    box_1B8E1.alert = False
    box_1B8E1.enabled = True
    box_1B8E1.active = True
    box_1B8E1.use_property_split = False
    box_1B8E1.use_property_decorate = False
    box_1B8E1.alignment = 'Left'.upper()
    box_1B8E1.scale_x = 0.550000011920929
    box_1B8E1.scale_y = 1.0
    if not True: box_1B8E1.operator_context = "EXEC_DEFAULT"
    split_1DDE0 = box_1B8E1.split(factor=0.7666666507720947, align=False)
    split_1DDE0.alert = False
    split_1DDE0.enabled = True
    split_1DDE0.active = True
    split_1DDE0.use_property_split = False
    split_1DDE0.use_property_decorate = False
    split_1DDE0.scale_x = 1.0
    split_1DDE0.scale_y = 1.0
    split_1DDE0.alignment = 'Expand'.upper()
    if not True: split_1DDE0.operator_context = "EXEC_DEFAULT"
    split_1DDE0.label(text='Set ' + label, icon_value=icon)
    op = split_1DDE0.operator('sna.set_custom_property_with_target_active_1ce39', text='Apply', icon_value=0, emboss=True, depress=False)
    op.sna_prop_name = name
    op.sna_prop_data = value


def sna_setpropertydata_B68AB(layout_function, label, name, value, icon):
    box_03CF2 = layout_function.box()
    box_03CF2.alert = False
    box_03CF2.enabled = True
    box_03CF2.active = True
    box_03CF2.use_property_split = False
    box_03CF2.use_property_decorate = False
    box_03CF2.alignment = 'Left'.upper()
    box_03CF2.scale_x = 0.550000011920929
    box_03CF2.scale_y = 1.0
    if not True: box_03CF2.operator_context = "EXEC_DEFAULT"
    split_665CD = box_03CF2.split(factor=0.7666666507720947, align=False)
    split_665CD.alert = False
    split_665CD.enabled = True
    split_665CD.active = True
    split_665CD.use_property_split = False
    split_665CD.use_property_decorate = False
    split_665CD.scale_x = 1.0
    split_665CD.scale_y = 1.0
    split_665CD.alignment = 'Expand'.upper()
    if not True: split_665CD.operator_context = "EXEC_DEFAULT"
    split_665CD.label(text='Set ' + label, icon_value=icon)
    op = split_665CD.operator('sna.set_custom_property_c600c', text='Apply', icon_value=0, emboss=True, depress=False)
    op.sna_prop_name = name
    op.sna_prop_data = value


def sna_addproperty_A1F3A(layout_function, label, name, value, icon):
    box_0FCB4 = layout_function.box()
    box_0FCB4.alert = False
    box_0FCB4.enabled = True
    box_0FCB4.active = True
    box_0FCB4.use_property_split = False
    box_0FCB4.use_property_decorate = False
    box_0FCB4.alignment = 'Left'.upper()
    box_0FCB4.scale_x = 0.550000011920929
    box_0FCB4.scale_y = 1.0
    if not True: box_0FCB4.operator_context = "EXEC_DEFAULT"
    split_61E18 = box_0FCB4.split(factor=0.7666666507720947, align=False)
    split_61E18.alert = False
    split_61E18.enabled = True
    split_61E18.active = True
    split_61E18.use_property_split = False
    split_61E18.use_property_decorate = False
    split_61E18.scale_x = 1.0
    split_61E18.scale_y = 1.0
    split_61E18.alignment = 'Expand'.upper()
    if not True: split_61E18.operator_context = "EXEC_DEFAULT"
    split_61E18.label(text='Add ' + label, icon_value=icon)
    op = split_61E18.operator('sna.set_custom_property_c600c', text='Add', icon_value=0, emboss=True, depress=False)
    op.sna_prop_name = name
    op.sna_prop_data = value


class SNA_PT_XYZ3D_CMS_6AD42(bpy.types.Panel):
    bl_label = 'xyz3d cms'
    bl_idname = 'SNA_PT_XYZ3D_CMS_6AD42'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'xyz3d'
    bl_order = 999
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_37C4B = layout.box()
        box_37C4B.alert = False
        box_37C4B.enabled = True
        box_37C4B.active = True
        box_37C4B.use_property_split = False
        box_37C4B.use_property_decorate = False
        box_37C4B.alignment = 'Expand'.upper()
        box_37C4B.scale_x = 1.0
        box_37C4B.scale_y = 1.0
        if not True: box_37C4B.operator_context = "EXEC_DEFAULT"
        box_37C4B.label(text='Models', icon_value=0)
        layout_function = box_37C4B
        sna_setpropertydata_B68AB(layout_function, 'Background Mesh', 'type', 'bgMesh', 583)
        layout_function = box_37C4B
        sna_setpropertydata_B68AB(layout_function, 'Interactable', 'type', 'interactable', 208)
        layout_function = box_37C4B
        sna_setpropertydataandtarget_805E1(layout_function, 'Raycast Mesh', 'type', 'raycastMesh', 551)
        layout_function = box_37C4B
        sna_setpropertydata_B68AB(layout_function, 'Player', 'type', 'player', 267)
        layout_function = box_37C4B
        sna_setpropertydata_B68AB(layout_function, 'Camera Bounds', 'type', 'cameraBounds', 240)
        box_0D7D0 = layout.box()
        box_0D7D0.alert = False
        box_0D7D0.enabled = True
        box_0D7D0.active = True
        box_0D7D0.use_property_split = False
        box_0D7D0.use_property_decorate = False
        box_0D7D0.alignment = 'Expand'.upper()
        box_0D7D0.scale_x = 1.0
        box_0D7D0.scale_y = 1.0
        if not True: box_0D7D0.operator_context = "EXEC_DEFAULT"
        box_0D7D0.prop(bpy.context.scene, 'sna_zone', text='Zone', icon_value=0, emboss=True)
        layout_function = box_0D7D0
        sna_setpropertydata_B68AB(layout_function, 'Zone (' + bpy.context.scene.sna_zone + ')', 'zone', bpy.context.scene.sna_zone, 482)
        box_0D7D0.prop(bpy.context.scene, 'sna_zoneindex', text='Index', icon_value=0, emboss=True)
        layout_function = box_0D7D0
        sna_setpropertydata_B68AB(layout_function, 'Index (' + str(bpy.context.scene.sna_zoneindex) + ')', 'index', str(bpy.context.scene.sna_zoneindex), 745)
        box_05EEE = layout.box()
        box_05EEE.alert = False
        box_05EEE.enabled = True
        box_05EEE.active = True
        box_05EEE.use_property_split = False
        box_05EEE.use_property_decorate = False
        box_05EEE.alignment = 'Expand'.upper()
        box_05EEE.scale_x = 1.0
        box_05EEE.scale_y = 1.0
        if not True: box_05EEE.operator_context = "EXEC_DEFAULT"
        box_05EEE.label(text='Animations', icon_value=0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'On Click Animation', 'onClickAnimations', 'Enter action name', 0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'On Hover Animation', 'onHoverAnimations', 'Enter action name', 0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'Looping Animation', 'loopAnimations', 'Enter action name', 0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'Camera Animation', 'cameraAnimations', 'Enter action name', 0)
        op = layout.operator('export_scene.gltf', text='Export GLTF', icon_value=693, emboss=True, depress=False)


class SNA_OT_Set_Custom_Property_C600C(bpy.types.Operator):
    bl_idname = "sna.set_custom_property_c600c"
    bl_label = "Set Custom Property"
    bl_description = "Set Custom Property In World Tab"
    bl_options = {"REGISTER", "UNDO"}
    sna_prop_name: bpy.props.StringProperty(name='Prop Name', description='', default='', subtype='NONE', maxlen=0)
    sna_prop_data: bpy.props.StringProperty(name='Prop Data', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_04F5A in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.selected[i_04F5A][self.sna_prop_name] = self.sna_prop_data
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Custom_Property_With_Target_Active_1Ce39(bpy.types.Operator):
    bl_idname = "sna.set_custom_property_with_target_active_1ce39"
    bl_label = "Set Custom Property With Target Active"
    bl_description = "Set Custom Property In World Tab"
    bl_options = {"REGISTER", "UNDO"}
    sna_prop_name: bpy.props.StringProperty(name='Prop Name', description='', default='', subtype='NONE', maxlen=0)
    sna_prop_data: bpy.props.StringProperty(name='Prop Data', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_1019E in range(len(bpy.context.view_layer.objects.selected)):
            if (bpy.context.view_layer.objects.selected[i_1019E] != bpy.context.view_layer.objects.active):
                operations['sna_selected'] = bpy.context.view_layer.objects.selected[i_1019E]
        operations['sna_selected'][self.sna_prop_name] = self.sna_prop_data
        bpy.context.view_layer.objects.active['raycastTarget'] = operations['sna_selected'].name
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Clear_Custom_Properties_E0032(bpy.types.Operator):
    bl_idname = "sna.clear_custom_properties_e0032"
    bl_label = "Clear Custom Properties"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_E1B63 in range(len(bpy.context.view_layer.objects.selected)):
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_zone = bpy.props.StringProperty(name='Zone', description='', default='HomePage', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_exportpath = bpy.props.StringProperty(name='ExportPath', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_zoneindex = bpy.props.IntProperty(name='ZoneIndex', description='', default=0, subtype='NONE')
    bpy.utils.register_class(SNA_PT_XYZ3D_CMS_6AD42)
    bpy.utils.register_class(SNA_OT_Set_Custom_Property_C600C)
    bpy.utils.register_class(SNA_OT_Set_Custom_Property_With_Target_Active_1Ce39)
    bpy.utils.register_class(SNA_OT_Clear_Custom_Properties_E0032)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_zoneindex
    del bpy.types.Scene.sna_exportpath
    del bpy.types.Scene.sna_zone
    bpy.utils.unregister_class(SNA_PT_XYZ3D_CMS_6AD42)
    bpy.utils.unregister_class(SNA_OT_Set_Custom_Property_C600C)
    bpy.utils.unregister_class(SNA_OT_Set_Custom_Property_With_Target_Active_1Ce39)
    bpy.utils.unregister_class(SNA_OT_Clear_Custom_Properties_E0032)
